export const FLAG_UNREAD = 1;
export const FLAG_ALERT = 2;
export const FLAG_RICHTEXT = 4;
export const FLAG_INFO = 8;
