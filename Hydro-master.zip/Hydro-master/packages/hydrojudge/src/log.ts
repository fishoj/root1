import { Logger } from '@hydrooj/utils/lib/utils';
export * from '@hydrooj/utils/lib/utils';
export default new Logger('judge');
