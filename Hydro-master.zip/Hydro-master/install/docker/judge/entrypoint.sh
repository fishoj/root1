#!/bin/sh

pm2 start sandbox
pm2-runtime start hydrojudge
